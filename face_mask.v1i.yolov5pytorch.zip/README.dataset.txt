# face_mask > 2024-09-22 1:48pm
https://universe.roboflow.com/ldotmithu/face_mask-g9ahl

Provided by a Roboflow user
License: CC BY 4.0

