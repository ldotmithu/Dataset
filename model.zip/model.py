import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score

# Load the dataset
file_path = 'bengaluru_house_prices.csv'
data = pd.read_csv(file_path)

# Step 1: Handle missing values
data = data.dropna(subset=['location', 'size', 'bath'])

# Step 2: Extract the number of bedrooms from the 'size' column
data['BHK'] = data['size'].str.extract('(\d+)').astype(float)

# Step 3: Clean and standardize the 'total_sqft' column
def convert_sqft_to_num(sqft):
    """
    Convert a total_sqft value into a numeric value.
    Handles ranges by taking the average, and returns NaN for invalid entries.
    """
    try:
        if '-' in sqft:  # Handle ranges like '2100-2850'
            tokens = sqft.split('-')
            return (float(tokens[0]) + float(tokens[1])) / 2
        return float(sqft)  # Convert directly to float
    except ValueError:
        return None

data['total_sqft'] = data['total_sqft'].apply(convert_sqft_to_num)

# Drop rows where 'total_sqft' conversion failed
data = data.dropna(subset=['total_sqft'])

# Step 4: Encode the 'location' column
location_counts = data['location'].value_counts()
rare_locations = location_counts[location_counts <= 10].index
data['location'] = data['location'].replace(rare_locations, 'Other')
data = pd.get_dummies(data, columns=['location'], drop_first=True)

# Drop unnecessary columns
data = data.drop(columns=['area_type', 'availability', 'size', 'society', 'balcony'])

# Define features and target variable
X = data.drop(columns=['price'])
y = data['price']

# Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize models
linear_model = LinearRegression()
random_forest_model = RandomForestRegressor(random_state=42)

# Train models
linear_model.fit(X_train, y_train)
random_forest_model.fit(X_train, y_train)

# Evaluate models
linear_preds = linear_model.predict(X_test)
rf_preds = random_forest_model.predict(X_test)

# Metrics for evaluation
linear_mae = mean_absolute_error(y_test, linear_preds)
rf_mae = mean_absolute_error(y_test, rf_preds)

linear_r2 = r2_score(y_test, linear_preds)
rf_r2 = r2_score(y_test, rf_preds)

# Print evaluation metrics
print("Linear Regression - MAE:", linear_mae, "R²:", linear_r2)
print("Random Forest Regressor - MAE:", rf_mae, "R²:", rf_r2)

print('linear_model_score',linear_model.score(X_test,y_test))
print('random_forest_model_ score',random_forest_model.score(X_test,y_test))
